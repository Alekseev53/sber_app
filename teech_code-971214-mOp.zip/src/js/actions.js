function startGame(context) {
    addAction({
        type: "start_game"
    }, context);
}

function rules(context) {
    addAction({
        type: "rules"
    }, context);
}

function settings(context) {
    addAction({
        type: "settings"
    }, context);
}

function setComplex(num, context) {
    addAction({
        type: "complex",
        note: num
    }, context);
}

function setMaxNumber(num, context) {
    addAction({
        type: "max_number",
        note: num
    }, context);
}

function save(context) {
    addAction({
        type: "save"
    }, context);
}

function generateExample(context) {
    addAction({
        type: "пример"
    }, context);
}

function ans(num ,context) {
    addAction({
        type: "add_note",
        note: num
    }, context);
}


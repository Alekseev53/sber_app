function reply_1(body, response){
    var replyData = {
        type: "raw",
        body: body
    };    
    response["responseData"] = response["responseData"] || {replies: []};
    response["responseData"].replies.push({
        "type":"text",
        "text":"This is a new answer",
        "category":"SCENARIO"
    });
}

function reply(body, response){
    var replyData = {
        type: "raw",
        body: body
    };    
    response.replies = response.replies || [];
    response.replies.push(replyData);
    // Modify the answer field directly
    response["responseData"] = response["responseData"] || {replies: []};
    response["responseData"].replies.answer = "This is a new answer_2"
    //response.answer = ;
    response["responseData"].replies.push({
               "type":"text",
               "text":"ВАЩЕ БОМБА",
               "state":"/Начинаем",
               "lang":"ru"
            });
}


function addAction(action, context){
    var command = {
        type: "smart_app_data",
        action: action
    };
    for (var index = 0; context.response.replies && index < context.response.replies.length; index ++) {
        if (context.response.replies[index].type === "raw" &&
            context.response.replies[index].body &&
            context.response.replies[index].body.items
        ) {
            context.response.replies[index].body.items.push({command: command});
            return;
        }
    }
    
    return reply({items: [{command: command}]}, context.response);
}


function addSuggestions(suggestions, context) {
    var buttons = [];
    
    suggestions.forEach (function(suggest) {
        buttons.push(
            {
                action: {
                    text: suggest,
                    type: "text"
                },
                title: suggest
            }
        );
    });

    reply({"suggestions": {"buttons": buttons}}, context.response);
}
